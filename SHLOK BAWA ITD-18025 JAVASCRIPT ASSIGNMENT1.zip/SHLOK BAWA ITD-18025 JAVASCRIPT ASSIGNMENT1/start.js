
var sh = document.getElementsByClassName("q");
var toggler = 0;


function nxt()
{
    if(toggler < 11)
        {
            toggler++;
        }
    
    for(var i = 0; i < sh.length; i++)
        {
            if(i==toggler)
                {
                    sh[i].style.display = "block";
                }
            
            else
                {
                    sh[i].style.display = "none";
                }
        }
}

function prev()
{
    
    if(toggler>0)
        {
            toggler--;
        }
    
    for(var i = 0; i < sh.length; i++)
        {
            if(i==toggler)
                {
                    sh[i].style.display = "block";
                }
            
            else
                {
                    sh[i].style.display = "none";
                }
        }
}



function sub()
			{
				var b=document.start.op1.value;
				var c=document.start.op2.value;
				var d=document.start.op3.value;
				var e=document.start.op4.value;
				var f=document.start.op5.value;
				var g=document.start.op6.value;
				var h=document.start.op7.value;
				var i=document.start.op8.value;
				var j=document.start.op9.value;
				var k=document.start.opa.value;
				var a=0;
				
				if(b=="y")
				{a++;}
				if(c=="y")
				{a++;}
				if(d=="y")
				{a++;}
				if(e=="y")
				{a++;}
				if(f=="y")
				{a++;}
				if(g=="y")
				{a++;}
				if(h=="y")
				{a++;}
				if(i=="y")
				{a++;}
				if(j=="y")
				{a++;}
				if(k=="y")
				{a++;}	
				
				if(a==10)
				{
					alert("YOU HAVE SCORED "+a+" EXCELLENT");
				}
				else if(a<5)
				{
					alert("YOU HAVE SCORED "+a+" WORK HARD");
				}
				else if(a>=5)
				{
					alert("YOU HAVE SCORED "+a+" GOOD PERFORMANCE");
				}
			}
